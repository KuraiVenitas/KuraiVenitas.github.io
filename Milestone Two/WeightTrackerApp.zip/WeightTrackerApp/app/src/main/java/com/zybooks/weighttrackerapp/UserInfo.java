package com.zybooks.weighttrackerapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Class is a table that contains a user's ID, username, password, SMS Permission Info and Goal Weight
@Entity (tableName = "user_table")
public class UserInfo {

    @PrimaryKey(autoGenerate = true)
    private int id; // id is auto generated through primary key
    private String username, password;
    private boolean smsPerm;
    private double goalWeight;

    // Default Constructor
    public UserInfo(){}

    // User Constructor
    public UserInfo(String username, String password, boolean smsPerm, double goalWeight){
        this.username = username;
        this.password = password;
        this.smsPerm = smsPerm;
        this.goalWeight = goalWeight;
    }

    // Getters
    public int getId(){ return id;}
    public String getUsername(){ return username;}
    public String getPassword(){ return password;}
    public double getGoalWeight(){ return goalWeight;}
    public boolean getSmsPerm(){ return smsPerm;}

    // Setters
    public void setId(int id){ this.id = id;}
    public void setUsername(String username){ this.username = username;}
    public void setPassword(String password){ this.password = password;}
    public void setSmsPerm(boolean smsPerm){ this.smsPerm = smsPerm;}
    public void setGoalWeight(double goalWeight){ this.goalWeight = goalWeight;}

}
