package com.zybooks.weighttrackerapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Class is a table that contains a user's weight entry and the date it was entered
@Entity(tableName = "weight_table")
public class WeightTable {

    @PrimaryKey(autoGenerate = true)
    private int id; // Similar to UserInfo, a unique id is auto generated
    private double weight;
    private String date; // Auto-formatted when the user inputs information

    // Default Constructor
    public WeightTable(){}

    // Constructor
    public WeightTable(int id, double weight, String date){
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Getters
    public int getId(){ return id;}
    public double getWeight(){ return weight;}
    public String getDate(){ return date;}

    // Setters
    public void setId(int id){ this.id = id;}
    public void setWeight(double weight){ this.weight = weight;}
    public void setDate(String date){ this.date = date;}

}

