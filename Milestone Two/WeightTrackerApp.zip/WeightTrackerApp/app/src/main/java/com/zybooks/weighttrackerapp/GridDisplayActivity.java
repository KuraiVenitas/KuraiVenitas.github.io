package com.zybooks.weighttrackerapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GridDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightEntryAdapter adapter;
    private AppDatabase db;
    private Button btnAddEntry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hides the default action bar for a cleaner layout
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_grid_display);

        // Set up the RecyclerView and adapter
        recyclerView = findViewById(R.id.recyclerView);
        adapter = new WeightEntryAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = AppDatabase.getDatabase(this);

        // Load weight entries from the database and display them
        new Thread(() -> {
            List<WeightTable> entries = db.weightDao().getAllEntriesNow();
            runOnUiThread(() -> adapter.setWeightList(entries));
        }).start();

        // Handle "Add Entry" button logic
        btnAddEntry = findViewById(R.id.btnAddEntry);
        btnAddEntry.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setHint("Enter your weight");

            new AlertDialog.Builder(this)
                    .setTitle("New Weight Entry")
                    .setView(input)
                    .setPositiveButton("Add", (dialog, which) -> {
                        String weightStr = input.getText().toString().trim();

                        if (!weightStr.isEmpty()) {
                            double weight = Double.parseDouble(weightStr);
                            String date = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(new Date());

                            WeightTable entry = new WeightTable();
                            entry.setWeight(weight);
                            entry.setDate(date);

                            new Thread(() -> {
                                db.weightDao().insert(entry);
                                List<WeightTable> updatedEntries = db.weightDao().getAllEntriesNow();
                                runOnUiThread(() -> adapter.setWeightList(updatedEntries));
                            }).start();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Setup the SMS permission toggle
        Switch switchSMS = findViewById(R.id.switchSMS);
        String username = getIntent().getStringExtra("username");

        new Thread(() -> {
            UserInfo user = db.userDao().getUserByUsername(username);
            if (user != null) {
                runOnUiThread(() -> switchSMS.setChecked(user.getSmsPerm()));

                switchSMS.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    user.setSmsPerm(isChecked);
                    new Thread(() -> db.userDao().update(user)).start();
                });
            }
        }).start();
    }
}
