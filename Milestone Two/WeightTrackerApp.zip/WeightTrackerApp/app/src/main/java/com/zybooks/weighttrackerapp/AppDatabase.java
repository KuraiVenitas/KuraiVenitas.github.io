package com.zybooks.weighttrackerapp;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Room database that holds user info and weight entry tables
@Database(entities = {UserInfo.class, WeightTable.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase{

    public abstract UserDAO userDao();
    public abstract WeightDAO weightDao();

    private static volatile AppDatabase INSTANCE;

    // Creates an instance of the AppDatabase for usage
    public static AppDatabase getDatabase(final Context context){
        // Checks if the database has been created
        if(INSTANCE == null){
            synchronized(AppDatabase.class){
                if(INSTANCE == null){
                    INSTANCE =  Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "weight_tracker_db").build();
                }
            }
        }
        return INSTANCE;
    }
}



