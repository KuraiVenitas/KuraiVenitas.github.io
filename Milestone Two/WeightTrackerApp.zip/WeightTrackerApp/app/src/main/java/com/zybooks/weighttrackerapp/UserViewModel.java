package com.zybooks.weighttrackerapp;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

// ViewModel that handles all user database operations like insertion and deletion
// The latter is mainly for testing purposes
public class UserViewModel extends AndroidViewModel {

    private final UserDAO userDao;
    private final LiveData<List<UserInfo>> allUsers;

    public UserViewModel(@NonNull Application application) {
        super(application);

        // Set up access to the database and userDAO
        AppDatabase db = AppDatabase.getDatabase(application);
        userDao = db.userDao();

        // Get live user list (used mainly for testing or admin use)
        allUsers = userDao.getAllEntries();
    }

    // Return the live list of all users
    public LiveData<List<UserInfo>> getAllUsers() {
        return allUsers;
    }

    // Insert a new user into the database (called during account creation)
    public void insert(UserInfo entry) {
        new Thread(() -> userDao.insert(entry)).start();
    }

    // Clears all user entries from the table (mainly for testing/reset)
    public void deleteAll() {
        new Thread(() -> userDao.deleteAllEntries()).start();
    }
}