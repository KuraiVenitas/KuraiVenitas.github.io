package com.zybooks.weighttrackerapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.lifecycle.LiveData;
import androidx.room.Update;

import java.util.List;
@Dao
public interface WeightDAO {

    // Called when a user enters a new weight into the database
    @Insert
    void insert(WeightTable entry);

    // Returns a live data list of all entries
    @Query("SELECT * FROM weight_table ORDER BY date DESC")
    LiveData<List<WeightTable>> getAllEntries();

    // Returns a static list
    @Query("SELECT * FROM weight_table ORDER BY date DESC")
    List<WeightTable> getAllEntriesNow(); // NOT LiveData

    // Updates the current weight selected for editing
    @Update
    void update(WeightTable entry);

    // Deletes the current weight selected for deletion
    @Delete
    void delete(WeightTable entry);

    // Deletes all entries from the weight table
    @Query("DELETE FROM weight_table")
    void deleteAllEntries();

}
