package com.zybooks.weighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    // Login screen UI elements
    EditText etUsername, etPassword;
    Button btnLogin, btnCreateAccount;
    AppDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        // Hides the default action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_login);

        // Links UI components
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        db = AppDatabase.getDatabase(this);

        // Create Account button logic
        btnCreateAccount.setOnClickListener(view -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                UserInfo newUser = new UserInfo(username, password, false, 0.0);

                new Thread(() -> {
                    db.userDao().insert(newUser);

                    // Popup to allow the user visual feedback for when account is created
                    Snackbar.make(view, "Account created for " + username, Snackbar.LENGTH_SHORT).show();
                    Log.d("USER", "Account created for: " + username);
                }).start();
            } else {
                Log.d("USER", "Username and/or password missing.");
            }
        });

        // Login button logic
        btnLogin.setOnClickListener(view -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            new Thread(() -> {
                UserInfo user = db.userDao().getUserByUsername(username);

                if (user != null && user.getPassword().equals(password)) {
                    Snackbar.make(view, "Login Successful: " + username, Snackbar.LENGTH_SHORT).show();
                    Log.d("USER", "Login successful: " + username);

                    runOnUiThread(() -> {
                        Intent intent = new Intent(MainActivity.this, GridDisplayActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                    });
                } else {
                    // Invalid login attempt
                    Snackbar.make(view, "Invalid login attempt", Snackbar.LENGTH_SHORT).show();
                    Log.d("USER", "Invalid login attempt for: " + username);
                }
            }).start();
        });

        // Clears the database on reboot for testing purposes (commented out by default)
        new Thread(() -> {
            db.clearAllTables();
            Log.d("DB_CLEAR", "All tables cleared");
        }).start();

    }
}
