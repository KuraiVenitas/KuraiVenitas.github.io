package com.zybooks.weighttrackerapp;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class WeightViewModel extends AndroidViewModel {

    private final WeightDAO weightDao;
    private final LiveData<List<WeightTable>> allWeights;

    public WeightViewModel(@NonNull Application application) {
        super(application);
        AppDatabase db = AppDatabase.getDatabase(application);
        weightDao = db.weightDao();
        allWeights = weightDao.getAllEntries();
    }

    public LiveData<List<WeightTable>> getAllWeights() {
        return allWeights;
    }

    public void insert(WeightTable entry) {
        new Thread(() -> weightDao.insert(entry)).start(); // Runs DB insert on background thread
    }

    public void deleteAll() {
        new Thread(weightDao::deleteAllEntries).start();
    }
}