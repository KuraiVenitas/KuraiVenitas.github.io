package com.zybooks.weighttrackerapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.ViewGroup;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


// Adapter for binding weight entries to the RecyclerView on the grid display screen
public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.WeightViewHolder> {

    private List<WeightTable> weightList;

    // Replaces the current list and refreshes the display with new entries
    public void setWeightList(List<WeightTable> weights) {
        this.weightList = weights;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_entries, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightTable entry = weightList.get(position);
        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(entry.getWeight() + " lbs");

        // Allows the user to edit the weight of an entry
        holder.btnEdit.setOnClickListener(v -> {
            Context context = v.getContext();
            EditText input = new EditText(context);
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setHint("Enter new weight");

            // Popup text and entry for the user to edit their weight
            new AlertDialog.Builder(context)
                    .setTitle("Edit Weight Entry")
                    .setView(input)
                    .setPositiveButton("Update", (dialog, which) -> {
                        String newWeightStr = input.getText().toString().trim();
                        if (!newWeightStr.isEmpty()) {
                            double newWeight = Double.parseDouble(newWeightStr);
                            entry.setWeight(newWeight);

                            // Update the entry in the database
                            new Thread(() -> {
                                AppDatabase db = AppDatabase.getDatabase(context);
                                db.weightDao().update(entry);

                                // Re-fetch updated list and update adapter
                                List<WeightTable> updatedEntries = db.weightDao().getAllEntriesNow();
                                ((Activity) context).runOnUiThread(() -> setWeightList(updatedEntries));
                            }).start();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });


        // Allows the user to delete the weight entry
        holder.btnDelete.setOnClickListener(v -> {
            Context context = v.getContext();

            new AlertDialog.Builder(context)
                    .setTitle("Delete Entry")
                    .setMessage("Are you sure you want to delete this entry?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        new Thread(() -> {
                            AppDatabase db = AppDatabase.getDatabase(context);
                            db.weightDao().delete(entry);

                            // Refresh the list
                            List<WeightTable> updatedEntries = db.weightDao().getAllEntriesNow();
                            ((Activity) context).runOnUiThread(() -> setWeightList(updatedEntries));
                        }).start();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

    }

    @Override
    public int getItemCount() {
        return (weightList != null) ? weightList.size() : 0;
    }

    // ViewHolder that represents a single row in the RecyclerView
    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        Button btnEdit, btnDelete;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}