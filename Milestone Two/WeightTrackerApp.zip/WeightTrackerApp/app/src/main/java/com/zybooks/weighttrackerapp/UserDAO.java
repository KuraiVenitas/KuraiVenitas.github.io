package com.zybooks.weighttrackerapp;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.lifecycle.LiveData;
import androidx.room.Update;

import java.util.List;
@Dao
public interface UserDAO {
    // Called when the user creates a new account
    @Insert
    void insert(UserInfo entry);

    // Gets all entries in the table. Testing purposes
    @Query("SELECT * FROM user_table ORDER BY id DESC")
    LiveData<List<UserInfo>> getAllEntries();

    // Retrieves a user's info by username from the data table
    @Query("SELECT * FROM user_table WHERE username = :username LIMIT 1")
    UserInfo getUserByUsername(String username);

    // Used to update the SMS permissions for the account
    // Can be implemented to include the user's goal weight
    @Update
    void update(UserInfo entry);

    // Deletes all entries. For testing purposes ONLY
    @Query("DELETE FROM user_table")
    void deleteAllEntries();

}


